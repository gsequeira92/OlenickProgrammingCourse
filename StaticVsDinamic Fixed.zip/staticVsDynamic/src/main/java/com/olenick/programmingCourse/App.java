package com.olenick.programmingCourse;

public class App {
    public static void main( String[] args ) {
        System.out.println("USAGE: mvn test");
    }
}
