package com.olenick.programmingCourse;

public abstract class Vehicle {
	protected static Double getWidth() {
		return 2.0;
	};

	protected static Double getHeight() {
		return 1.0;
	};

	protected static Double getLength() {
		return 3.0;
	};

	protected abstract String getTypeAsString();

	public Dimensions getDimensions() {
		return new Dimensions(getWidth(), getHeight(), getLength());
	}

	protected abstract String getName();

	public String toString() {
		return "" + getTypeAsString() + " '" + getName() + "'";
	}
}
